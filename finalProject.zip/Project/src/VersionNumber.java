
public class VersionNumber {
	String version;
	public VersionNumber(String version) {
		this.version = version;
	}
	
	public String getVersion() {
		return version;
	}
	
	public void setVersion(String nVersion) {
		version = nVersion;
	}

}
